package com.dto;

public class GoodsDTO {
	int itemNum;
	String itemName;
	String company;
	String cateCode;
	String itemImg;
	String itemContent;
	int count;
	public GoodsDTO(int itemNum, String itemName, String company, String cateCode, String itemImg, String itemContent,
			int count) {
		super();
		this.itemNum = itemNum;
		this.itemName = itemName;
		this.company = company;
		this.cateCode = cateCode;
		this.itemImg = itemImg;
		this.itemContent = itemContent;
		this.count = count;
	}
	public GoodsDTO() {
		super();
	}
	public int getItemNum() {
		return itemNum;
	}
	public void setItemNum(int itemNum) {
		this.itemNum = itemNum;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getCateCode() {
		return cateCode;
	}
	public void setCateCode(String cateCode) {
		this.cateCode = cateCode;
	}
	public String getItemImg() {
		return itemImg;
	}
	public void setItemImg(String itemImg) {
		this.itemImg = itemImg;
	}
	public String getItemContent() {
		return itemContent;
	}
	public void setItemContent(String itemContent) {
		this.itemContent = itemContent;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	@Override
	public String toString() {
		return "GoodsDTO [itemNum=" + itemNum + ", itemName=" + itemName + ", company=" + company + ", cateCode="
				+ cateCode + ", itemImg=" + itemImg + ", itemContent=" + itemContent + ", count=" + count + "]";
	}
	
	
	
	
}
